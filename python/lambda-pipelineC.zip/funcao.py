def pipelineC(event, context):
    print("funcionou!")

    return {
        'statusCode': 200,
    }
